"use client";

import clsx from "clsx";
import { modals } from "@mantine/modals";
import { DEFAULT_MODAL_SETTINGS } from "@/src/utils/constants";
import React from "react";
import { Convert } from "../icons/convert";
import { Transfer } from "../icons/transfer";
import { Pocket } from "../icons/pocket";
import { Withdraw } from "../icons/withdraw";
import { FiatOtc } from "../icons/fiat-otc";
import { P2pTrading } from "../icons/p2p-trading";
import { MethodSheet, SUCCESS_METHOD_STYLES } from "../shared/method-select-modal";
import { useAssets } from "@/src/hooks/use-assets";
import { useRouter } from "next/navigation";
import { ConvertAsset } from "../transactions/convert-asset";
import { BalanceCloak } from "../shared/balance-cloak";
import { BalanceRevealControl } from "../shared/balance-reveal-control";
import { MdRefresh } from "react-icons/md";
import { Skeleton } from "../shared/skeleton";
import { usePortfolioWs } from "@/src/hooks/use-portfolio-ws";
import type { PortfolioBalanceAccount } from "@/src/lib/portfolio-store";

export const WalletCard = ({
  title,
  children,
  variant = "account",
}: {
  title?: string;
  children?: React.ReactNode;
  variant?: "account" | "dashboard";
}) => {
  const { push } = useRouter();
  const {
    handleOpenInternalTransferModal,
    handleOpenExternalTransferModal,
  } = useAssets();
  const accountMap: Record<string, PortfolioBalanceAccount> = {
    "Funding Account": "funding",
    "Spot": "spot",
    "Futures": "futures",
    "Margin": "margin",
  };
  const singleAccount = title ? accountMap[title] : undefined;

  // Account pages request their own balance alongside portfolio holdings;
  // the overview requests the overall balance.
  const { balances, refreshBalances, isRefreshing } = usePortfolioWs(
    singleAccount
      ? { coins: true, balanceAccount: singleAccount }
      : { balance: true }
  );

  // Pick the account-specific balance or the overall balance.
  const acctBal = singleAccount ? balances[singleAccount] : balances["total"];
  const [balanceWaitExpired, setBalanceWaitExpired] = React.useState(false);
  const hasUsdBalance = acctBal?.inUsd != null;

  React.useEffect(() => {
    setBalanceWaitExpired(false);
    if (hasUsdBalance) return;

    const timeout = window.setTimeout(() => setBalanceWaitExpired(true), 45_000);
    return () => window.clearTimeout(timeout);
  }, [hasUsdBalance, singleAccount]);

  const showBalanceLoader = !hasUsdBalance && !balanceWaitExpired;

  const safeNum = (val: string | null | undefined) => {
    const n = parseFloat(val ?? "");
    return isNaN(n) ? 0 : n;
  };

  const totalUsd = safeNum(acctBal?.inUsd);
  const totalBtc = safeNum(acctBal?.inBtc);

  // Server-provided 24h P&L (from get_portfolio / get_portfolio_balance).
  // pnlPercentage is a fraction (e.g. 0.00496626) → ×100 for display.
  const pnl = safeNum(acctBal?.pnl);
  const pnlPct = safeNum(acctBal?.pnlPercentage) * 100;

  const pnlDisplay = (pnl >= 0 ? "+" : "") + pnl.toFixed(2);
  const pnlPctDisplay = (pnlPct >= 0 ? "+" : "") + pnlPct.toFixed(2) + "%";
  const isPnlUp = pnl >= 0;

  const balance = { inUsd: totalUsd, inBtc: totalBtc };

  // Dashboard-style cards (the dashboard itself, plus spot/futures/overview)
  // open the withdrawal method modal and swap "Ext. Transfer" for "Earn";
  // other account pages keep the full transfer set.
  const isDashboard = variant === "dashboard" || title == null;

  const openWithdrawalMethodModal = () => {
    const go = (href: string) => {
      modals.closeAll();
      push(href);
    };
    modals.open({
      children: (
        <MethodSheet
          title="Select withdrawal method"
          subtitle="Choose how you want to withdraw"
          onClose={modals.closeAll}
          options={[
            {
              icon: <Withdraw />,
              title: "Crypto withdrawal",
              description: "On-chain withdrawal | Bybit UID/email/mobile number",
              onSelect: () => go("/transactions/withdrawal"),
            },
            {
              icon: <FiatOtc />,
              title: "Sell for NGN",
              description: "Receive cash instantly in your bank account or e-wallet",
              ...SUCCESS_METHOD_STYLES,
              onSelect: () => go("/transactions/fiat-withdraw"),
            },
            {
              icon: <P2pTrading />,
              title: "P2P Trading",
              description: "Sell directly to users | Competitive prices | Local payments",
              ...SUCCESS_METHOD_STYLES,
              onSelect: () => go("/trades/p2p"),
            },
          ]}
        />
      ),
      ...DEFAULT_MODAL_SETTINGS,
    });
  };

  const buttons = [
    {
      icon: Withdraw,
      text: "Withdraw",
      isPrimary: false,
      action: () => {
        if (isDashboard) {
          openWithdrawalMethodModal();
        } else {
          push("/transactions/withdrawal");
        }
      },
    },
    {
      icon: Transfer,
      text: "Transfer",
      isPrimary: false,
      action: () => {
        if (title === "Futures") {
          handleOpenInternalTransferModal("funding", "futures");
        } else {
          handleOpenInternalTransferModal();
        }
      },
    },
    ...(isDashboard
      ? [
          {
            icon: Pocket,
            text: "Earn",
            isPrimary: false,
            action: () => push("/assets/earn"),
          },
        ]
      : [
          {
            icon: Transfer,
            text: "Ext. Transfer",
            isPrimary: false,
            action: handleOpenExternalTransferModal,
          },
        ]),
    {
      icon: Convert,
      text: "Convert",
      isPrimary: false,
      action: () =>
        modals.open({
          children: <ConvertAsset />,
          ...DEFAULT_MODAL_SETTINGS,
        }),
    },
  ];

  return (
    <div className="relative rounded-card overflow-hidden border border-white/[0.05] bg-gradient-to-br from-surface via-elevated to-black animate-fade-up">
      {/* Glow blobs */}
      <div className="absolute -top-16 -right-16 w-64 h-64 rounded-full bg-primary/20 blur-[100px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-48 h-48 rounded-full bg-blue-600/10 blur-[80px] pointer-events-none" />

      <div className="relative z-10 p-5 sm:p-6 lg:p-7 flex flex-col gap-5">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          {/* Left: label + balance + P&L */}
          <div className="flex flex-col gap-3 max-w-md">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-bold uppercase tracking-widest text-primary/70">
                {title ?? "Total Assets"}
              </span>
              <div className="flex items-center gap-2">
                <BalanceRevealControl />
                <button
                  type="button"
                  onClick={refreshBalances}
                  aria-label={`Refresh ${title ?? "total assets"} balance`}
                  title="Refresh balance"
                  className="text-white/40 hover:text-white transition-colors"
                >
                  <MdRefresh size={17} className={isRefreshing ? "animate-spin" : ""} />
                </button>
              </div>
            </div>

            {showBalanceLoader ? (
              <Skeleton variant="balance" />
            ) : (
              <>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl sm:text-3xl font-extrabold text-white tabular-nums leading-none">
                    <BalanceCloak balance={balance?.inUsd ?? 0} />
                  </span>
                  <span className="text-base font-semibold text-white/40">USD</span>
                </div>
                <div className="flex items-center gap-1 text-sm text-white/50">
                  <span>≈</span>
                  <span><BalanceCloak balance={balance?.inBtc ?? 0} /></span>
                  <span className="text-xs text-white/30">BTC</span>
                </div>
              </>
            )}

            {/* P&L line */}
            <div className="mt-1 flex items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-white/40">
                Today&apos;s P&L
              </span>
              {showBalanceLoader ? (
                <Skeleton variant="text" width="100px" height="14px" />
              ) : (
                <span className={clsx("flex items-center gap-1 text-sm font-mono font-bold", isPnlUp ? "text-[#25AB42]" : "text-error-1")}>
                  <span>{pnlDisplay}</span>
                  <span>({pnlPctDisplay})</span>
                </span>
              )}
            </div>
          </div>

          {/* Right: action cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 lg:shrink-0">
            {buttons.map((item) => (
              <button
                key={item.text}
                onClick={item.action}
                className={clsx(
                  "flex flex-col items-center justify-center gap-1 rounded-xl p-3.5 min-w-[96px] transition-all duration-200 active:scale-95",
                  item.isPrimary
                    ? "bg-primary/10 border border-primary/20 text-primary hover:bg-primary hover:text-white hover:border-primary"
                    : "bg-white/[0.04] border border-white/[0.05] text-white/80 hover:bg-white/[0.08] hover:border-white/15"
                )}
              >
                <item.icon className="w-5 h-5" />
                <span className="text-xs font-semibold">{item.text}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Optional slot: Deposit / Fiat Channels merged into the same hero */}
        {children != null && (
          <div className="flex flex-col gap-3 border-t border-white/[0.08] pt-5">
            {children}
          </div>
        )}
      </div>
    </div>
  );
};
