import React from "react";

export const Dot = () => {
  return (
    <svg
      width="7"
      height="6"
      viewBox="0 0 7 6"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle cx="3.5" cy="3" r="3" fill="#4D77F0" />
    </svg>
  );
};
