import React from "react";

export const Dollar = () => {
  return (
    <svg
      width="23"
      height="24"
      viewBox="0 0 23 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      xmlnsXlink="http://www.w3.org/1999/xlink"
    >
      <rect
        y="0.166748"
        width="22.8571"
        height="22.8571"
        fill="url(#pattern0_45_807)"
      />
      <defs>
        <pattern
          id="pattern0_45_807"
          patternContentUnits="objectBoundingBox"
          width="1"
          height="1"
        >
          <use xlinkHref="#image0_45_807" transform="scale(0.0111111)" />
        </pattern>
        <image
          id="image0_45_807"
          width="90"
          height="90"
          xlinkHref="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFoAAABaCAYAAAA4qEECAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFeklEQVR4nO2dW4iVVRTHt41lZiURlaVRUUH0ll1QKrTIoiC6mAbTDSuHwNDU6iGQoqAbFTJdIISiICoL7YKXiuolKHJq0oh8yEsXTR0dKyhHmvEXi7OKU53vO9+Zs9c++zuzf3BehnP2/u91vtmXtddax7lEIpFIJBKJRCKRSBQD6ADOBW4DHgfeAjYAm4B+YL+++vVvG/Q9j+lnzpE2CnY3sgAmAXcB7wK/0jy/AO8AC4CJbiQDjAVuAj4AhrBjEHgfuBE41I0UgMP1SdtGeHYBDwDjXbsCHAzcA+yh9YiGxaLJtRPAhcDXxMdG4BJXdmROBJ4FDhAvoq0bGOPKCHAy8Bnl4QvgNFcm5N/R0zYtNLItvNiVAeAaYB/lZT9wvYsZoMt4TxwKGcNcFyPA1Xo4aBeGgNkuJmReAwYsR+2y+7aeRi51MQCcHmLhc9n9h1ggTw1r1f8Pcoxui8xx2RpC0NPSfbYeRoLgsjWEojusdf99rA524nPZOkIhY50W2sijgfUBB0kEhkb9NeEcUeqFC8GgfqHP5Wh5BugNuLVcGMrIRwRwdf4MLJGblwZ0naif2WGsrU986rZWrgzoXuN58EngyCb0jQeeMl4/Fvu1au3rJ6snZp/PkxhwHfC7kdbtptdiwM3YcYuB3msNfS+dvvVWC5eLVAuWGWp+wkjzWsuQgCGjKWNSAV/Ka8APVZ/bofEcVxWYs2UB843sco63MLTEXViwok6/TxdoQ2I4DmuyjeFwp4WhJbjFgq6cPmc30M6LOe3MMNK+0uIkKF4sC6bl9PtmA+3ItHZSzrRnQb/X8DONhbPizJx+32uwrbXA8zVey7DjbJ+GluBBK87K6fdu4meOT0NLVKcVl9WJbno58riQR30a+m1DofcXnLpejSSczG5BNHaJ9jYYOz1Fp5TlwPeGurzrLzLALcZir2hC2wT1a8htz2bCs9mnoXcbi/0ROMaDzlGyXQTeCDiv9/mxcmUAcu1uzZfACR41nwd8G0D3QNkMjQanewvHEr828BElMrT11PFf1gG3N3MBUKX9KOA7SjJ1WC+GWfwJfAI8BFwJHDdM/bJYlmIxDHrjXYct6jLtyvJt1NB/kC640W/vxO8bKz3ytBcYw0utcPPGdAT3hZwcR+WM4T5KcAS3dCr5ZGbOGO6gBE4lKzfpGnkiMl5bh9HeIzljWIQNk30ausPI8b8kp8+Hh9He/Jz25MuL2/GvQuVezjev5PR3bIPZtbvzjvFGN/j+FsIqoZJWbPFEHJLT5xkFE0ElhGxqnbRoi4yEeRaGnmgUSNhZYNqaBbyuZSP+0M/tBD6WoMN6J0hNR7Y4TE3wbmgVLFUCfLNVQs1MBFc0H63J9r5Z4wxFS9kHC5bL6c1Ab4fubEoXEjZW50MLXvCZJ6Lz8kojrdvMa38YB6Gv83F9D1wEfGOoc5Efa7Y2EP2ABs5c3kgag1ZSmAmsxhaJ4xtna2XbVbwW8oWuAh6scxD5EPiNMCwIYuSqELGvCIjL1tK+yUI6wAtS+lsgtHJLEFy2hlAsDWXXrBRlcbyb47I1hODzPFdBECQh3TCk9x9y+rdmL3CKiwFgunXVGZfdtyUSZjHDxYTkkrRhYZRZLkakPE6blPoZlLgSFzNa8qfMxasGoivxUyddzXyBNFr4prsyIcEtwKeUh56Wl/Rpcp/dHXlqhGhb2vJ9ssfj+nriQzSd79oJKo6ohUbpwo3Sp5fNo127AozTQf7UAgPv1ELdTYcDlwYqjvobNAnT8qAzqPeGnSOq9HwtpEqAJLDrHZ/EejRLv7Y1zywkoOxQubmeDNyqtycrtDjVJr1x+fvnQfbo33r1PfLeOfrZ9PMgiUQikUgkEolEIuEK8heRnVKfPUn7CgAAAABJRU5ErkJggg=="
        />
      </defs>
    </svg>
  );
};
