import React, { ComponentProps } from "react";

export const SubAccount = (props?: ComponentProps<"svg">) => {
  return (
    <svg
      width="22"
      height="15"
      viewBox="0 0 22 15"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M15 6.5C16.66 6.5 17.99 5.16 17.99 3.5C17.99 1.84 16.66 0.5 15 0.5C13.34 0.5 12 1.84 12 3.5C12 5.16 13.34 6.5 15 6.5ZM7 6.5C8.66 6.5 9.99 5.16 9.99 3.5C9.99 1.84 8.66 0.5 7 0.5C5.34 0.5 4 1.84 4 3.5C4 5.16 5.34 6.5 7 6.5ZM7 8.5C4.67 8.5 0 9.67 0 12V14.5H14V12C14 9.67 9.33 8.5 7 8.5ZM15 8.5C14.71 8.5 14.38 8.52 14.03 8.55C15.19 9.39 16 10.52 16 12V14.5H22V12C22 9.67 17.33 8.5 15 8.5Z"
        fill={props?.color ?? "currentColor"}
        fillOpacity="0.55"
      />
    </svg>
  );
};
