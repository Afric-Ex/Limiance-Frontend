import React from "react";

export const Basket = (props: React.SVGProps<SVGSVGElement>) => {
  return (
    <svg
      {...props}
      width="36"
      height="36"
      viewBox="0 0 36 36"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M9 3L4.5 9V30C4.5 30.7956 4.81607 31.5587 5.37868 32.1213C5.94129 32.6839 6.70435 33 7.5 33H28.5C29.2956 33 30.0587 32.6839 30.6213 32.1213C31.1839 31.5587 31.5 30.7956 31.5 30V9L27 3H9Z"
        stroke="white"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M24 15C24 16.5913 23.3679 18.1174 22.2426 19.2426C21.1174 20.3679 19.5913 21 18 21C16.4087 21 14.8826 20.3679 13.7574 19.2426C12.6321 18.1174 12 16.5913 12 15"
        stroke="white"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M4.5 9H31.5"
        stroke="white"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
