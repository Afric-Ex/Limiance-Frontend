import { api } from "../lib/axios";
import type { OrderHistoryStatus } from "../lib/order-ws";
import { ApiResponse } from "../types/api";
import { OrderBooksResponse } from "../types/trading";

export type OrderSide = "buy" | "sell";
export type TradingMarket = "spot" | "margin" | "futures";
export type TradingMarketFilter = TradingMarket | "all";
export type SpotOrderType = "buy_limit" | "sell_limit" | "buy_stop" | "sell_stop" | "market";

const compactSymbol = (base: string, quote: string) => `${base}${quote}`.toUpperCase();
const slashSymbol = (base: string, quote: string) => `${base}/${quote}`.toUpperCase();
const filterOrdersByPair = (orders: any[], pair?: string) => {
  if (!pair) return orders;
  const normalizedPair = pair.replace("/", "").toUpperCase();
  return orders.filter((order: any) => {
    const orderPair =
      order.pair ||
      order.symbol ||
      (order.base && order.quote ? `${order.base}/${order.quote}` : "");
    return String(orderPair).replace("/", "").toUpperCase() === normalizedPair;
  });
};

export const tradingKeys = {
  orderBooks: ["order-books"],
  openOrders: (pair?: string, market?: TradingMarketFilter) =>
    market ? ["open-orders", pair, market] : ["open-orders", pair],
  orderHistory: (market?: TradingMarket, pair?: string) => ["order-history", market, pair],
  // In tradingKeys:
  unifiedOrderHistory: (marketType?: string, page?: number) => ["unified-order-history", marketType, page],
  tradeHistory: (market?: TradingMarket, pair?: string) => ["trade-history", market, pair],
  spotRecentTrades: (symbol?: string) => ["spot-recent-trades", symbol],
  klineData: (symbol: string, interval: string, market?: string) => ["kline", symbol, interval, market],
  gainersLosers: ["gainers-losers"],
  spotPrice: (symbol: string) => ["spot-price", symbol],
  spotOcos: (status?: string) => ["spot-ocos", status],
  spotPnlHistory: (symbol?: string) => ["spot-pnl-history", symbol],
  marginOrderHistory: ["margin-order-history"],
  marginOpenOrders: ["margin-open-orders"],
  marginBorrowHistory: ["margin-borrow-history"],
  marginLiquidationHistory: ["margin-liquidation-history"],
  marginPnlHistory: (symbol?: string) => ["margin-pnl-history", symbol],
  futuresPnlHistory: (symbol?: string) => ["futures-pnl-history", symbol],
  convertHistory: ["convert-history"],
  fiatOrderHistory: ["fiat-order-history"],
  paymentHistory: ["payment-history"],
  /** Filters-only key for the infinite-scroll list; `page` is owned by react-query. */
  paymentHistoryList: (filters: Record<string, unknown> = {}) => [
    "payment-history",
    "list",
    filters,
  ],
  listedTokens: (params?: { query?: string; page?: number; limit?: number; isTradable?: boolean }) => ["listed-tokens", params],
  listedCurrencies: ["listed-currencies"],
} as const;

export const tradingService = {
  orderBooks: async (): Promise<ApiResponse<OrderBooksResponse>> => {
    const response = await api.get("trading/order_books");
    return response.data;
  },

  marketOrderHistory: async (
    market: TradingMarket,
    params?: { pair?: string; page?: number; limit?: number; status?: string }
  ) => {
    const response = await api.get(`trading/${market}/order_history`, { params });
    return response.data;
  },

  tradeHistory: async (market: TradingMarket) => {
    const response = await api.get("trading/history", { params: { market } });
    return response.data;
  },

  // ─── Spot ────────────────────────────────────────────────────────────────
  placeLimitOrder: async (data: {
    side: OrderSide;
    base: string;
    quote: string;
    type: "buy_limit" | "sell_limit";
    price: number;
    quantity: number;
  }) => {
    const endpoint = data.side === "buy" ? "trading/spot/buy_limit" : "trading/spot/sell_limit";
    const response = await api.post(endpoint, {
      symbol: slashSymbol(data.base, data.quote),
      side: data.side.toUpperCase(),
      type: "LIMIT",
      quantity: Number(data.quantity),
      price: Number(data.price)
    });
    return response.data;
  },

  placeStopOrder: async (data: {
    side: OrderSide;
    base: string;
    quote: string;
    type: "buy_stop" | "sell_stop";
    stopPrice: number;
    quantity: number;
  }) => {
    const endpoint = data.side === "buy" ? "trading/spot/buy_stop" : "trading/spot/sell_stop";
    const response = await api.post(endpoint, {
      symbol: slashSymbol(data.base, data.quote),
      side: data.side.toUpperCase(),
      type: "STOP",
      quantity: Number(data.quantity),
      price: Number(data.stopPrice),
      stopPrice: Number(data.stopPrice),
    });
    return response.data;
  },

  placeMarketOrder: async (data: {
    side: OrderSide;
    base: string;
    quote: string;
    type: "market";
    quantity: number;
    price?: number; // required by backend for max-notional validation on market orders
  }) => {
    const endpoint = data.side === "buy" ? "trading/spot/buy" : "trading/spot/sell";
    const response = await api.post(endpoint, {
      symbol: slashSymbol(data.base, data.quote),
      side: data.side.toUpperCase(),
      type: "MARKET",
      quantity: Number(data.quantity),
      ...(data.price && data.price > 0 ? { price: Number(data.price) } : {}),
    });
    return response.data;
  },

  closeSpotOrder: async (orderId: string, symbol?: string) => {
    const response = await api.post("trading/spot/close_order", {
      orderId,
      ...(symbol ? { symbol } : {}),
    });
    return response.data;
  },

  spotOrderStatus: async (orderId: string) => {
    const response = await api.get(`trading/transactions/spot/${orderId}`);
    return response.data;
  },

  // ─── Margin ──────────────────────────────────────────────────────────────
  getMarginAccount: async () => {
    const response = await api.get("trading/margin/account");
    return response.data;
  },
  createMarginAccount: async () => {
    const response = await api.post("trading/margin/account");
    return response.data;
  },

  placeMarginLimitOrder: async (data: {
    side: OrderSide;
    base: string;
    quote: string;
    type: "buy_limit" | "sell_limit";
    price: number;
    quantity: number;
    leverage: number;
  }) => {
    const endpoint = data.side === "buy" ? "trading/margin/buy_limit" : "trading/margin/sell_limit";
    const response = await api.post(endpoint, {
      symbol: compactSymbol(data.base, data.quote),
      side: data.side.toUpperCase(),
      type: "LIMIT",
      quantity: Number(data.quantity),
      price: Number(data.price),
      leverage: data.leverage,
    });
    return response.data;
  },

  placeMarginMarketOrder: async (data: {
    side: OrderSide;
    base: string;
    quote: string;
    type: "market";
    quantity: number;
    leverage: number;
    price?: number; // forwarded for backend max-notional validation
  }) => {
    const endpoint = data.side === "buy" ? "trading/margin/buy" : "trading/margin/sell";
    const response = await api.post(endpoint, {
      symbol: compactSymbol(data.base, data.quote),
      side: data.side.toUpperCase(),
      type: "MARKET",
      quantity: Number(data.quantity),
      leverage: data.leverage,
      ...(data.price && data.price > 0 ? { price: Number(data.price) } : {}),
    });
    return response.data;
  },

  placeMarginStopOrder: async (data: {
    side: OrderSide;
    base: string;
    quote: string;
    type: "buy_stop" | "sell_stop";
    stopPrice: number;
    quantity: number;
    leverage: number;
  }) => {
    const endpoint = data.side === "buy" ? "trading/margin/buy_stop" : "trading/margin/sell_stop";
    const response = await api.post(endpoint, {
      symbol: compactSymbol(data.base, data.quote),
      side: data.side.toUpperCase(),
      type: "STOP",
      quantity: Number(data.quantity),
      stopPrice: Number(data.stopPrice),
      leverage: data.leverage,
    });
    return response.data;
  },

  closeMarginOrder: async (orderId: string) => {
    const response = await api.delete(`trading/margin/orders/${orderId}`);
    return response.data;
  },

  cancelAllMarginOrders: async (symbol?: string) => {
    const response = await api.post("trading/margin/cancel_all", null, {
      params: symbol ? { symbol } : {},
    });
    return response.data;
  },

  marginBalance: async () => {
    const response = await api.get("wallet/balance/margin");
    return response.data;
  },

  marginPnlHistory: async (params?: { symbol?: string; page?: number; limit?: number }) => {
    const response = await api.get("trading/margin/pnl_history", { params });
    return response.data;
  },

  marginPositions: async () => {
    // Disabled: the backend does not serve this endpoint yet, so polling it only
    // produced failing requests. Callers get an empty list until it exists.
    return { data: [] as any[] };
  },

  setMarginLeverage: async (max_leverage: number) => {
    const response = await api.put("trading/margin/leverage", { max_leverage });
    return response.data;
  },

  setMarginMode: async (mode: "cross" | "isolated") => {
    const response = await api.put("trading/margin/mode", { mode });
    return response.data;
  },

  borrowMargin: async (data: { asset: string; amount: number }) => {
    const response = await api.post("trading/margin/borrow", data);
    return response.data;
  },

  repayMargin: async (data: { asset: string; amount: number }) => {
    const response = await api.post("trading/margin/repay", data);
    return response.data;
  },

  marginOrderHistory: async (params?: {
    status?: OrderHistoryStatus;
    page?: number;
    limit?: number;
  }) => {
    const response = await api.get("trading/order_history", { 
      params: { 
        ...params,
        market_type: "margin"
      } 
    });
    return response.data;
  },

  marginTradeHistory: async () => {
    return tradingService.tradeHistory("margin");
  },

  fetchMarginOpenOrders: async (params?: { pair?: string }) => {
    const response = await api.get("trading/orders", { 
      params: { 
        status: "open",
        market_type: "margin"
      } 
    });
    if (!Array.isArray(response.data?.data)) return response.data;
    return { ...response.data, data: filterOrdersByPair(response.data.data, params?.pair) };
  },

  marginBorrowHistory: async () => {
    const response = await api.get("trading/margin/borrow_history");
    return response.data;
  },

  marginLiquidationHistory: async () => {
    const response = await api.get("trading/margin/liquidation_history");
    return response.data;
  },

  placeMarginOCOOrder: async (data: {
    symbol: string;
    order_side: string;
    tp_trigger_price: string;
    sl_trigger_price: string;
    quantity: string;
    tp_limit_price: string;
    sl_limit_price: string;
  }) => {
    const response = await api.post("trading/margin/oco", data);
    return response.data;
  },

  // ─── Futures ─────────────────────────────────────────────────────────────
  placeFuturesOrder: async (data: {
    pair: string;
    side: "buy" | "sell";
    type: "market" | "limit" | "stop_buy" | "stop_sell";
    quantity: number;
    leverage?: number;
    price?: number;
    stopPrice?: number;
    marginMode?: "cross" | "isolated";
    takeProfit?: number;
    stopLoss?: number;
  }) => {
    const normalizedType =
      data.type === "market" ? "market" : data.type === "limit" ? "limit" : "stop";
    const response = await api.post("trading/futures/place_order", {
      pair: data.pair,
      side: data.side === "buy" ? "LONG" : "SHORT",
      type: normalizedType,
      quantity: data.quantity,
      leverage: data.leverage,
      marginMode: data.marginMode ?? "cross",
      ...(normalizedType === "limit" && typeof data.price === "number" ? { price: data.price } : {}),
      ...(normalizedType === "stop" && typeof data.stopPrice === "number" ? { price: data.stopPrice } : {}),
      ...(typeof data.takeProfit === "number" ? { takeProfit: data.takeProfit } : {}),
      ...(typeof data.stopLoss === "number" ? { stopLoss: data.stopLoss } : {}),
    });
    return response.data;
  },

  setFuturesMode: async (mode: "cross" | "isolated") => {
    const response = await api.post("trading/futures/set_margin_mode", { mode });
    return response.data;
  },

  setFuturesLeverage: async (leverage: number) => {
    const response = await api.post("trading/futures/set_leverage", { leverage });
    return response.data;
  },

  acceptFutures: async () => {
    const response = await api.post("users/accept_futures");
    return response.data;
  },

  fetchFuturesOpenOrders: async (params?: { pair?: string }) => {
    const response = await api.get("trading/orders", { 
      params: { 
        status: "open",
        market_type: "futures"
      } 
    });
    if (!Array.isArray(response.data?.data)) return response.data;
    return { ...response.data, data: filterOrdersByPair(response.data.data, params?.pair) };
  },

  futuresOrderHistory: async (params?: { pair?: string; page?: number; limit?: number; status?: OrderHistoryStatus }) => {
    const response = await api.get("trading/order_history", { 
      params: { 
        ...params,
        market_type: "futures"
      } 
    });
    if (!Array.isArray(response.data?.data)) return response.data;
    return { ...response.data, data: filterOrdersByPair(response.data.data, params?.pair) };
  },

  futuresTradeHistory: async () => {
    return tradingService.tradeHistory("futures");
  },

  closeFuturesPosition: async (data: { positionId: string }) => {
    // Correct endpoint: POST /trading/futures/close_position/{position_id}
    const response = await api.post(`trading/futures/close_position/${data.positionId}`);
    return response.data;
  },

  partialCloseFuturesPosition: async (data: { positionId: string; close_quantity: string }) => {
    // POST /trading/futures/partial_close/{position_id} body: { close_quantity: "0.05" }
    const response = await api.post(`trading/futures/partial_close/${data.positionId}`, {
      close_quantity: data.close_quantity,
    });
    return response.data;
  },


  updateFuturesPositionTPSL: async (data: { positionId: string; take_profit_price?: number | string; stop_loss_price?: number | string }) => {
    const response = await api.patch(`trading/futures/position/${data.positionId}/tpsl`, {
      take_profit_price: data.take_profit_price,
      stop_loss_price: data.stop_loss_price,
    });
    return response.data;
  },

  cancelFuturesOrder: async (orderId: string) => {
    const response = await api.delete(`trading/futures/orders/${orderId}`);
    return response.data;
  },

  editFuturesOrder: async (data: { orderId: string; price?: string; quantity?: string }) => {
    const { orderId, ...body } = data;
    const response = await api.patch(`trading/futures/orders/${orderId}`, body);
    return response.data;
  },

  cancelAllFuturesOrders: async (symbol?: string) => {
    const response = await api.post("trading/futures/cancel_all", null, {
      params: symbol ? { symbol } : {},
    });
    return response.data;
  },

  futuresPnlHistory: async (params?: { symbol?: string; page?: number; limit?: number }) => {
    const response = await api.get("trading/futures/pnl_history", { params });
    return response.data;
  },


  // ─── Orders & History ────────────────────────────────────────────────────
  fetchOpenOrders: async (params?: { pair?: string; market_type?: TradingMarketFilter }) => {
    const m = params?.market_type || "spot";
    const response = await api.get("trading/order_history", {
      params: {
        status: "open",
        market_type: m,
        type: m,
        ...(params?.pair ? { pair: params.pair } : {}),
      },
    });
    if (!params?.pair || !Array.isArray(response.data?.data)) return response.data;
    return { ...response.data, data: filterOrdersByPair(response.data.data, params.pair) };
  },

  cancelSpotOrder: async (orderId: string) => {
    const response = await api.delete(`trading/spot/orders/${orderId}`);
    return response.data;
  },

  cancelAllSpotOrders: async (symbol?: string) => {
    const response = await api.post("trading/spot/cancel_all", null, {
      params: symbol ? { symbol } : {},
    });
    return response.data;
  },

  placeSpotOCOOrder: async (data: {
    pair: string;
    quantity: string;
    takeProfit?: string;
    stopLoss?: string;
  }) => {
    const response = await api.post("trading/spot/ocos", data);
    return response.data;
  },

  fetchSpotOCOs: async (params?: { page?: number; limit?: number; status?: string }) => {
    const response = await api.get("trading/spot/ocos", { params });
    return response.data;
  },

  cancelSpotOCO: async (ocoId: string) => {
    const response = await api.delete(`trading/spot/ocos/${ocoId}`);
    return response.data;
  },

  spotPnlHistory: async (params?: { symbol?: string; page?: number; limit?: number }) => {
    const response = await api.get("trading/spot/pnl_history", { params });
    return response.data;
  },

  spotOrderHistory: async (params?: {
    status?: OrderHistoryStatus;
    page?: number;
    limit?: number;
  }) => {
    const response = await api.get("trading/order_history", { 
      params: { 
        ...params,
        market_type: "spot"
      } 
    });
    return response.data;
  },

  spotTradeHistory: async () => {
    return tradingService.tradeHistory("spot");
  },

  fetchSpotOrderById: async (id: string) => {
    const response = await api.get(`trading/transactions/spot/${id}`);
    return response.data;
  },

  spotRecentTrades: async (params?: { symbol?: string }) => {
    const response = await api.get("trading/spot/recent_trades", { params });
    return response.data;
  },

  // ─── Market Data ─────────────────────────────────────────────────────────
  klineData: async (params: {
    symbol: string;
    interval: string;
    limit?: number;
    startTime?: string | number;
    endTime?: string | number;
    market?: string;
  }) => {
    const response = await api.get("trading/kline/historical", {
      params: {
        symbol: params.symbol,
        ...(params.startTime !== undefined && params.startTime !== ""
          ? { "start-time": String(params.startTime), startTime: String(params.startTime) }
          : {}),
        ...(params.endTime !== undefined && params.endTime !== ""
          ? { "end-time": String(params.endTime), endTime: String(params.endTime) }
          : {}),
        interval: params.interval,
        limit: params.limit || 500,
        ...(params.market ? { market: params.market, marketType: params.market } : {}),
      },
    });
    return response.data;
  },

  gainersLosers: async (limit = 100) => {
    const response = await api.get(`trading/24_hours_movers`, { params: { limit } });
    return response.data;
  },

  /** Latest spot price in USD/NGN for one market, e.g. `LIMUSDT`. */
  spotPrice: async (symbol: string) => {
    const response = await api.get("trading/spot/price", { params: { symbol } });
    return response.data;
  },

  conversionRate: async (data: { fromAsset: string; toAsset: string; quantity: string }) => {
    const response = await api.post("trading/conversion_rate", data);
    return response.data;
  },

  listedPairs: async (params?: { q?: string; page?: number; limit?: number }) => {
    const response = await api.get("trading/listed_pairs", { params });
    return response.data;
  },

  listedCurrencies: async (params?: { q?: string; page?: number; limit?: number }) => {
    const response = await api.get("trading/listed_currencies", { params });
    return response.data;
  },

  listedTokens: async (params?: {
    page?: number;
    limit?: number;
    query?: string;
    isTradable?: boolean;
  }): Promise<{
    data: { symbol: string; name?: string; logo?: string }[];
    totalRecords?: string | number;
  } | null> => {
    const response = await api.get("trading/listed_tokens", { params });
    return response.data;
  },

  // ─── Payments & History ───────────────────────────────────────────────────
  convertHistory: async () => {
    const response = await api.get("trading/convert/history");
    return response.data;
  },

  fiatOrderHistory: async () => {
    const response = await api.get("wallet/fiat/history");
    return response.data;
  },

  paymentHistory: async (params?: {
    page?: number;
    limit?: number;
    start_date?: string;
    end_date?: string;
  }) => {
    const response = await api.get("trading/payment/history", { params });
    return response.data;
  },

  getOrderHistory: async (params?: {
    market_type?: "spot" | "margin" | "futures" | "all";
    page?: number;
    limit?: number;
    status?: OrderHistoryStatus | string;
    order_type?: string;
    side?: string;
    pair?: string;
    from?: string;
    to?: string;
  }) => {
    const response = await api.get("trading/order_history", { params: {
      market_type: params?.market_type ?? "all",
      type: params?.market_type ?? "all",
      page: params?.page ?? 1,
      limit: params?.limit ?? 20,
      ...(params?.status && { status: String(params.status).toLowerCase() }),
      ...(params?.order_type && { order_type: params.order_type }),
      ...(params?.side && { side: params.side }),
      ...(params?.pair && { pair: params.pair }),
      ...(params?.from && { from: params.from }),
      ...(params?.to && { to: params.to }),
    }});
    return response;
  },
};