import { createTheme } from "@mantine/core";

export const theme = createTheme({
  cursorType: "pointer",
  primaryColor: "primary",
  primaryShade: 4,
  fontFamily:
    'var(--font-inter), -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"',
  fontFamilyMonospace:
    'var(--font-jetbrains-mono), ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace',
  colors: {
    primary: [
      "#e6ebfc",
      "#b5c4f7",
      "#83a0f4",
      "#668af2",
      "#4d77f0",
      "#3561e8",
      "#1e4bd6",
      "#1239c4",
      "#0928b2",
      "#051ba0",
    ],
    // ── Design-system semantic colors (Limiance-Exchange-Design-System.md §3) ──
    surface: ["#121212", "#121212", "#121212", "#121212", "#121212", "#121212", "#121212", "#121212", "#121212", "#121212"],
    elevated: ["#222222", "#222222", "#222222", "#222222", "#222222", "#222222", "#222222", "#222222", "#222222", "#222222"],
    muted: ["#292929", "#292929", "#292929", "#292929", "#292929", "#292929", "#292929", "#292929", "#292929", "#292929"],
    line: ["#343434", "#343434", "#343434", "#343434", "#343434", "#343434", "#343434", "#343434", "#343434", "#343434"],
    secondary: ["#727679", "#727679", "#727679", "#727679", "#727679", "#727679", "#727679", "#727679", "#727679", "#727679"],
    buy: ["#25AB42", "#25AB42", "#25AB42", "#25AB42", "#25AB42", "#25AB42", "#25AB42", "#25AB42", "#25AB42", "#25AB42"],
    sell: ["#F6465D", "#F6465D", "#F6465D", "#F6465D", "#F6465D", "#F6465D", "#F6465D", "#F6465D", "#F6465D", "#F6465D"],
    warning: ["#FF9500", "#FF9500", "#FF9500", "#FF9500", "#FF9500", "#FF9500", "#FF9500", "#FF9500", "#FF9500", "#FF9500"],
  },
});
