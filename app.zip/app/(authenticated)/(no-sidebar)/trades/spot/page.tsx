"use client";

import { Search } from "@/src/components/icons/search";
import { PlaceSpot, type TpslPreview } from "@/src/components/trades/place-spot";
import { tradingKeys, tradingService } from "@/src/services/trading";
import { useMarketFeed } from "@/src/hooks/use-market-feed";
import { useOrderBook } from "@/src/hooks/use-order-book";
import { useRecentTrades } from "@/src/hooks/use-recent-trades";
import { OrderBookTabs } from "@/src/components/trades/order-book-tabs";
import { SpotPairHeader } from "@/src/components/trades/spot-pair-header";
import { TradingPanel } from "@/src/components/trades/trading-panel";
import { Skeleton } from "@/src/components/shared/skeleton";
import { SpotTradePageSkeleton } from "@/src/components/skeletons/trades";
import { usePortfolioWs } from "@/src/hooks/use-portfolio-ws";
import { readList } from "@/src/lib/api-response";
import { getLatestTradePrice } from "@/src/lib/recent-trades";
import {
  Tabs,
  TabsList,
  TabsPanel,
  TabsTab,
  TextInput,
  Popover,
  PopoverTarget,
  PopoverDropdown,
} from "@mantine/core";
import { useQuery } from "@tanstack/react-query";
import dynamic from "next/dynamic";
import { MdKeyboardArrowDown } from "react-icons/md";
import clsx from "clsx";
import { useState, useEffect, Suspense } from "react";
import { useSearchParams } from "next/navigation";

import { MobileTopBar } from "@/src/components/shared/mobile-top-bar";
import { SidebarMenuButton } from "@/src/components/shared/sidebar-menu";
import { IoChevronDown, IoChevronUp, IoSwapHorizontal, IoBarChartOutline, IoListOutline } from "react-icons/io5";
import { MobileBottomSheet } from "@/src/components/shared/mobile-bottom-sheet";
import { MobileBottomNav } from "@/src/components/shared/mobile-bottom-nav";

const CandlestickChart = dynamic(
  () => import("@/src/components/trades/candlestick-chart"),
  { ssr: false, loading: () => <Skeleton variant="chart" height="100%" /> }
);

import type { OrderLevel } from "@/src/components/trades/candlestick-chart";

type TradeMode = "spot" | "cross" | "isolated";

function SpotTrades() {
  const searchParams = useSearchParams();
  const initialPair = searchParams.get("pair")?.replace("_", "/") ?? "BTC/USDT";
  const [selectedPair, setSelectedPair] = useState(initialPair);
  const [pairSearch, setPairSearch] = useState("");
  // Mobile and desktop headers are BOTH mounted (one is hidden by CSS), so they
  // need separate state — sharing it would open both dropdowns at once.
  const [pairMenuOpen, setPairMenuOpen] = useState(false);
  const [pairMenuDesktopOpen, setPairMenuDesktopOpen] = useState(false);
  const [tradeMode, setTradeMode] = useState<TradeMode>("spot");
  const [leverage, setLeverage] = useState(1);
  const [clickedPrice, setClickedPrice] = useState<number | null>(null);
  const [chartLastPrice, setChartLastPrice] = useState<number | null>(null);
  
  // Mobile chart toggle
  const [chartExpanded, setChartExpanded] = useState(false);
  const [, setOrderBookOpen] = useState(false);
  const [mobileMode, setMobileMode] = useState<"trade" | "chart">("chart");
  const [quickOrderOpen, setQuickOrderOpen] = useState(false);
  const [quickOrderSide, setQuickOrderSide] = useState<"buy" | "sell">("buy");
  const [tpslPreview, setTpslPreview] = useState<TpslPreview>({});
  // Last placed trade — shown as an orange FILL tag on the chart
  const [placedFill, setPlacedFill] = useState<{
    side: string;
    price: number;
    quantity: number;
    takeProfit?: number;
    stopLoss?: number;
  } | null>(null);
  useEffect(() => {
    setPlacedFill(null);
    setTpslPreview({});
  }, [selectedPair]);

  const feed = useMarketFeed(selectedPair);
  const orderBook = useOrderBook(selectedPair, "spot");
  // Refresh-only: the order form below owns the portfolio subscription for this
  // screen, so this page just needs to keep the portfolio subscription alive.
  usePortfolioWs({});

  const { data: openOrders } = useQuery({
    queryKey: tradingKeys.openOrders(selectedPair),
    queryFn: () => tradingService.fetchOpenOrders({ pair: selectedPair }),
    select: (res: unknown) => readList<Record<string, any>>(res),
    retry: false,
    throwOnError: false,
  });

  const { recentTrades, recentTradesLoading } = useRecentTrades(selectedPair, "spot");
  const lastTradedPrice = getLatestTradePrice(recentTrades) ?? feed.price ?? null;

  // Price flash effect
  const [flashClass, setFlashClass] = useState("");
  const [prevPrice, setPrevPrice] = useState<number | null>(null);
  useEffect(() => {
    if (feed.price !== null && prevPrice !== null && feed.price !== prevPrice) {
      setFlashClass(feed.price > prevPrice ? "animate-flash-green" : "animate-flash-red");
      const t = setTimeout(() => setFlashClass(""), 600);
      return () => clearTimeout(t);
    }
    setPrevPrice(feed.price);
  }, [feed.price, prevPrice]);

  const formatPrice = (val: number | null) =>
    val !== null ? val.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : null;
  const formatOrderDate = (value: unknown, timeOnly = false) => {
    if (!value) return "—";
    const raw = String(value);
    const date = new Date(raw);
    if (!Number.isNaN(date.getTime())) return timeOnly ? date.toLocaleTimeString() : date.toLocaleString();
    return timeOnly ? (raw.split(/\s+/).pop() ?? raw) : raw;
  };

  // Shared renderer for recent market trades (desktop + mobile)
  const renderRecentTrades = (limit = 20) => (
    <div className="w-full">
      {recentTradesLoading ? (
        <div className="p-4 flex justify-center"><Skeleton variant="table-row" count={5} columns={3} className="w-full" /></div>
      ) : !recentTrades?.length ? (
        <div className="p-4 text-center text-xs text-white/40">No recent trades</div>
      ) : (
        <div className="flex flex-col">
          <div className="grid grid-cols-4 px-3 py-1.5 text-2xs text-white/40">
            <span>Time</span><span className="text-center">Direction</span><span className="text-right">Price</span><span className="text-right">Qty</span>
          </div>
          <div className="flex flex-col divide-y divide-white/[0.04]">
            {[...recentTrades]
              .sort((a: any, b: any) => {
                const ta = new Date(a?.createdAt ?? a?.time ?? a?.ts ?? 0).getTime();
                const tb = new Date(b?.createdAt ?? b?.time ?? b?.ts ?? 0).getTime();
                return (Number.isNaN(tb) ? 0 : tb) - (Number.isNaN(ta) ? 0 : ta);
              })
              .slice(0, limit)
              .map((t: any, i: number) => {
              const side = String(t.side ?? "").toUpperCase();
              const isBuy = side === "BUY";
              const priceColor = isBuy ? "text-success-6" : side === "SELL" ? "text-error-1" : "text-white/80";
              return (
                <div key={t.id ?? t.tradeId ?? i} className="grid grid-cols-4 px-3 py-1.5 text-micro font-mono tabular-nums items-center">
                  <span className="text-white/40">{formatOrderDate(t.createdAt ?? t.time ?? t.ts, true)}</span>
                  <span className="text-center">
                    <span className={isBuy ? "text-success-6" : "text-error-1"}>{isBuy ? "BUY" : side === "SELL" ? "SELL" : "—"}</span>
                  </span>
                  <span className={"text-right " + priceColor}>{Number(t.price).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 6 })}</span>
                  <span className="text-right text-white/80">{Number(t.quantity ?? t.qty ?? t.filled).toLocaleString()}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );

  const isPositive = (feed.changePercent24h ?? 0) >= 0;
  const changeColor = isPositive ? "text-success-6" : "text-error-1";

  const maxAskVol = Math.max(...orderBook.sellOrders.map((o) => o.quantity), 0.001);
  const maxBidVol = Math.max(...orderBook.buyOrders.map((o) => o.quantity), 0.001);
  const selectedMarket = (feed.markets || []).find(
    (m) => `${m.base}/${m.quote}` === selectedPair || (m.symbol || "").replace("/", "").toUpperCase() === selectedPair.replace("/", "").toUpperCase()
  );
  const bestAsk = orderBook.sellOrders[0]?.price;
  const bestBid = orderBook.buyOrders[0]?.price;
  const filteredMarkets = pairSearch.trim()
    ? (feed.markets || []).filter(
        (m: any) =>
          (m.symbol || m.pair || "").toLowerCase().includes(pairSearch.toLowerCase()) ||
          (m.base || "").toLowerCase().includes(pairSearch.toLowerCase())
      )
    : feed.markets || [];

  const handleSelectPair = (base: string, quote: string) => {
    setSelectedPair(`${base}/${quote}`);
    setPairSearch("");
    setPairMenuOpen(false);
    setPairMenuDesktopOpen(false);
  };

  const orderBookMidPrice = bestAsk && bestBid ? (bestAsk + bestBid) / 2 : bestAsk ?? bestBid ?? null;
  const effectiveMarketPrice = feed.price ?? selectedMarket?.last_price ?? selectedMarket?.lastPrice ?? selectedMarket?.price ?? orderBookMidPrice;
  const chartOrderLevels: OrderLevel[] = (openOrders ?? []).flatMap((order: any) => {
    const entry = Number(order.price ?? order.entryPrice);
    const takeProfit = Number(order.takeProfit ?? order.take_profit ?? order.take_profit_price ?? order.tp_trigger_price ?? order.tp_price ?? order.tp);
    const stopLoss = Number(order.stopLoss ?? order.stop_loss ?? order.stop_loss_price ?? order.sl_trigger_price ?? order.sl_price ?? order.sl);
    const side = String(order.side ?? "").toUpperCase();
    const amount = Number(order.amount ?? order.quantity);

    return [
      ...(entry
        ? [{
            id: `${order.id}-entry`,
            label: "Entry",
            price: entry,
            color: "entry" as const,
            detail: `${side || "ORDER"}${amount ? ` ${amount}` : ""}`,
          }]
        : []),
      ...(takeProfit
        ? [{
            id: `${order.id}-tp`,
            label: "TP",
            price: takeProfit,
            color: "tp" as const,
          }]
        : []),
      ...(stopLoss
        ? [{
            id: `${order.id}-sl`,
            label: "SL",
            price: stopLoss,
            color: "sl" as const,
          }]
        : []),
    ];
  });

  // Live TP/SL preview from the order form, shown before the order is placed
  const previewTpslLevels: OrderLevel[] = [];
  const isFinitePositive = (v: number | undefined): v is number => Number.isFinite(v) && (v ?? 0) > 0;
  if (isFinitePositive(tpslPreview.buyTp)) previewTpslLevels.push({ id: "preview-tp-buy", label: "TP", price: tpslPreview.buyTp, color: "tp", detail: "BUY" });
  if (isFinitePositive(tpslPreview.buySl)) previewTpslLevels.push({ id: "preview-sl-buy", label: "SL", price: tpslPreview.buySl, color: "sl", detail: "BUY" });
  if (isFinitePositive(tpslPreview.sellTp)) previewTpslLevels.push({ id: "preview-tp-sell", label: "TP", price: tpslPreview.sellTp, color: "tp", detail: "SELL" });
  if (isFinitePositive(tpslPreview.sellSl)) previewTpslLevels.push({ id: "preview-sl-sell", label: "SL", price: tpslPreview.sellSl, color: "sl", detail: "SELL" });
  previewTpslLevels.forEach((level) => chartOrderLevels.push(level));

  // Orange tag for the trade the user just placed
  if (placedFill && Number.isFinite(placedFill.price) && placedFill.price > 0) {
    chartOrderLevels.push({
      id: `fill-${placedFill.side}-${placedFill.price}-${placedFill.quantity}`,
      label: "FILL",
      price: placedFill.price,
      color: "fill",
      detail: `${(placedFill.side || "").toUpperCase()}${placedFill.quantity ? ` ${placedFill.quantity}` : ""}`,
    });
  }
  if (placedFill?.takeProfit && Number.isFinite(placedFill.takeProfit) && placedFill.takeProfit > 0) {
    chartOrderLevels.push({
      id: `placed-${placedFill.side}-tp`,
      label: "TP",
      price: placedFill.takeProfit,
      color: "tp",
      detail: `${(placedFill.side || "").toUpperCase()} · placed`,
    });
  }
  if (placedFill?.stopLoss && Number.isFinite(placedFill.stopLoss) && placedFill.stopLoss > 0) {
    chartOrderLevels.push({
      id: `placed-${placedFill.side}-sl`,
      label: "SL",
      price: placedFill.stopLoss,
      color: "sl",
      detail: `${(placedFill.side || "").toUpperCase()} · placed`,
    });
  }

  const [base, quote] = selectedPair.split("/");

  return (
    <div className="flex gap-1 flex-col h-full bg-black min-h-screen page-enter">

      {/* ─── Mobile Sticky Top Bar ─── */}
      <MobileTopBar
        title=""
        leftElement={
          <div className="flex items-center gap-1">
            <SidebarMenuButton className="-ml-1 h-9 w-9" />
            <Popover width={300} position="bottom-start" shadow="md" opened={pairMenuOpen} onChange={setPairMenuOpen}>
              <PopoverTarget>
                <button
                  aria-label="Change trading pair"
                  onClick={() => setPairMenuOpen((v) => !v)}
                  className="flex items-center gap-1 px-1 py-0.5 rounded tap-scale"
                >
                  <IoSwapHorizontal size={16} className="text-white/40 shrink-0" />
                  <span className="text-body font-bold text-white/90">{selectedPair}</span>
                  <MdKeyboardArrowDown className="text-white/40" size={16} />
                </button>
              </PopoverTarget>
              <PopoverDropdown className="!bg-[#181a20] !border-white/[0.06] !p-0">
                <div className="flex flex-col">
                  <div className="p-3 border-b border-white/[0.06]">
                    <TextInput
                      classNames={{
                        input: "!h-8 !bg-white/5 placeholder:!text-white/30 !border-0 focus:!border focus:!border-primary !rounded text-xs",
                      }}
                      placeholder="Search pairs (BTC, ETH…)"
                      leftSection={<Search className="w-4 h-4" />}
                      value={pairSearch}
                      onChange={(e) => setPairSearch(e.target.value)}
                    />
                  </div>
                  <div className="max-h-[50vh] overflow-auto py-1">
                    {feed.marketsLoading ? (
                      <Skeleton variant="table-row" count={5} columns={2} className="px-2" />
                    ) : filteredMarkets.length === 0 ? (
                      <div className="text-center py-8 text-xs text-white/30">No pairs found</div>
                    ) : (
                      filteredMarkets.slice(0, 30).map((m) => (
                        <button
                          key={m.symbol}
                          onClick={() => handleSelectPair(m.base, m.quote)}
                          className={clsx(
                            "w-full flex items-center justify-between px-4 py-2.5 hover:bg-white/[0.04] transition-colors text-left",
                            selectedPair === `${m.base}/${m.quote}` && "bg-white/[0.03]"
                          )}
                        >
                          <div className="flex flex-col gap-0">
                            <span className="text-xs font-bold text-white/90">
                              {m.base}<span className="text-white/40">/{m.quote}</span>
                            </span>
                            <span className="text-2xs text-white/30">{m.symbol}</span>
                          </div>
                          <span className={clsx("text-xs font-semibold", m.percent_change >= 0 ? "text-success-2" : "text-error-1")}>
                            {m.percent_change >= 0 ? "+" : ""}{m.percent_change}%
                          </span>
                        </button>
                      ))
                    )}
                  </div>
                </div>
              </PopoverDropdown>
            </Popover>
          </div>
        }
        rightElement={
          <div className="flex items-center gap-2">
            
            <div className="flex items-center bg-white/[0.06] rounded-lg p-0.5 gap-0.5 min-[1150px]:hidden">
              <button onClick={() => setMobileMode("chart")} className={`p-1.5 rounded-md transition-all ${mobileMode === "chart" ? "bg-white/15 text-white" : "text-white/40"}`}><IoBarChartOutline size={15} /></button>
              <button onClick={() => setMobileMode("trade")} className={`p-1.5 rounded-md transition-all ${mobileMode === "trade" ? "bg-white/15 text-white" : "text-white/40"}`}><IoListOutline size={15} /></button>
            </div>
            <span className={clsx("text-sm font-bold tabular-nums", changeColor)}>
              {effectiveMarketPrice !== null ? formatPrice(effectiveMarketPrice) : "—"}
            </span>
            <span className={clsx(
              "text-2xs font-semibold px-1.5 py-0.5 rounded",
              isPositive ? "bg-success-6/10 text-success-6" : "bg-error-1/10 text-error-1"
            )}>
              {feed.changePercent24h !== null ? `${isPositive ? "+" : ""}${feed.changePercent24h.toFixed(2)}%` : "—"}
            </span>
          </div>
        }
      />

      {/* 3-Column Layout */}
      <div className="hidden min-[1150px]:grid min-[1150px]:grid-cols-[minmax(0,1fr)_305px_305px] min-[1150px]:grid-rows-[auto_max(480px,calc(100vh-164px))_auto] content-start gap-1 px-1 pt-1 flex-1 pb-1 min-h-0 relative">
        
        {/* Desktop pair bar: sits above chart + order book, beside the trade form */}
        <SpotPairHeader
          className="min-[1150px]:col-span-2 min-[1150px]:col-start-1 min-[1150px]:row-start-1"
          selectedPair={selectedPair}
          feed={feed}
          flashClass={flashClass}
          menuOpen={pairMenuDesktopOpen}
          onMenuOpenChange={setPairMenuDesktopOpen}
          pairSearch={pairSearch}
          onPairSearchChange={setPairSearch}
          markets={filteredMarkets}
          onSelectPair={handleSelectPair}
          currentPrice={effectiveMarketPrice}
        />

        {/* MOBILE: Floating Order Book Button */}
        <button className="min-[1150px]:hidden fixed bottom-[90px] right-4 z-40 bg-[#1c1e27] border border-white/[0.08] text-white text-xs font-bold px-4 py-2.5 rounded-full shadow-lg tap-scale flex items-center gap-2" onClick={() => setOrderBookOpen(true)}>
          <span>Order Book</span>
        </button>

        {/* Chart Column (Responsive) */}
        <div className="flex flex-col gap-1 overflow-hidden min-w-0 min-[1150px]:col-start-1 min-[1150px]:row-start-2">
          <div className={clsx("bg-[#181a20] rounded relative flex flex-col transition-all duration-300", chartExpanded ? "h-[950px] shrink-0" : "flex-1 min-[1150px]:min-h-0")}>
            <CandlestickChart
              key={selectedPair}
              symbol={selectedPair}
              market="spot"
              orderBook={orderBook}
              orderLevels={chartOrderLevels}
              priceRange={{ min: feed.low24h, max: feed.high24h }}
              lastPrice={lastTradedPrice}
              onLastPriceChange={setChartLastPrice}
              insightTabs
              recentTrades={recentTrades}
            />
            
            {/* Mobile chart expand toggle */}
            <button 
              onClick={() => setChartExpanded(!chartExpanded)}
              className="min-[1150px]:hidden absolute bottom-2 right-2 w-8 h-8 bg-black/50 backdrop-blur border border-white/10 rounded-lg flex items-center justify-center text-white/60 hover:text-white"
            >
              {chartExpanded ? <IoChevronUp /> : <IoChevronDown />}
            </button>
          </div>
        </div>

        {/* COL 2: Order Book and live market trades */}
        <OrderBookTabs
          className="hidden min-[1150px]:flex min-h-0 min-[1150px]:col-start-2 min-[1150px]:row-start-2"
          buyOrders={orderBook.buyOrders}
          sellOrders={orderBook.sellOrders}
          recentTrades={recentTrades}
          recentTradesLoading={recentTradesLoading}
          base={base}
          quote={quote}
          currentPrice={effectiveMarketPrice}
          dayChangePercent={feed.changePercent24h}
          buyPercentage={orderBook.buyPercentage}
          sellPercentage={orderBook.sellPercentage}
          isConnected={orderBook.isConnected}
          lastUpdated={orderBook.lastUpdated}
          onSelectPrice={setClickedPrice}
        />
        {/* Desktop trading panel: Open Orders / Positions / Order History / ... (spans under chart + order book) */}
        <div className="hidden min-[1150px]:flex flex-col min-w-0 min-h-[260px] max-h-[420px] col-span-2 col-start-1 row-start-3">
          <TradingPanel selectedPair={selectedPair} market="spot" className="flex-1 min-h-0" />
        </div>

        {/* COL 3: Trade Form (Responsive) */}
        <div className="bg-[#181a20] flex flex-col overflow-y-auto max-[1150px]:min-h-[400px] min-[1150px]:col-start-3 min-[1150px]:row-start-1 min-[1150px]:row-span-3">
          <Tabs
            classNames={{
              tab: "!py-2.5 !px-3 max-[1150px]:!py-4 max-[1150px]:flex-1 hover:!bg-transparent data-[active]:!text-white data-[active]:!border-b-2 data-[active]:!border-primary !border-b-2 !border-transparent !rounded-none font-bold text-xs max-[1150px]:text-sm text-white/50",
              list: "flex items-center gap-1 px-1 before:!border-0 w-full",
              panel: "!p-4",
            }}
            value={tradeMode}
            onChange={(v) => {
              const m = (v ?? "spot") as TradeMode;
              setTradeMode(m);
              if (m === "spot") setLeverage(1);
              else if (m === "cross" && leverage > 10) setLeverage(10);
            }}
          >
            <div className="px-4 pt-3 text-base font-bold text-white">Trade</div>
            <TabsList className="w-full">
              <TabsTab value="spot">Spot</TabsTab>
              <TabsTab value="cross">Cross {tradeMode === "cross" ? `${leverage}x` : "3x"}</TabsTab>
              <TabsTab value="isolated">Isolated {tradeMode === "isolated" ? `${leverage}x` : "10x"}</TabsTab>
            </TabsList>
            <TabsPanel value="spot">
              <PlaceSpot pair={selectedPair} mode="spot" sideToggle leverage={1} marketPrice={effectiveMarketPrice} clickedPrice={clickedPrice} onTpslChange={setTpslPreview} onFill={setPlacedFill} />
            </TabsPanel>
            <TabsPanel value="cross">
              <PlaceSpot
                pair={selectedPair}
                mode="cross"
                sideToggle
                leverage={leverage}
                onLeverageChange={setLeverage}
                marketPrice={effectiveMarketPrice}
                clickedPrice={clickedPrice}
                onTpslChange={setTpslPreview} onFill={setPlacedFill}
              />
            </TabsPanel>
            <TabsPanel value="isolated">
              <PlaceSpot
                pair={selectedPair}
                mode="isolated"
                sideToggle
                leverage={leverage}
                onLeverageChange={setLeverage}
                marketPrice={effectiveMarketPrice}
                clickedPrice={clickedPrice}
                onTpslChange={setTpslPreview} onFill={setPlacedFill}
              />
            </TabsPanel>
          </Tabs>
        </div>

      </div>

      

      {/* MOBILE VIEW */}
      <div className="min-[1150px]:hidden flex flex-col flex-1 pb-[80px] min-h-0 relative">
        {/* Mobile market stats strip */}
        <div className="shrink-0 grid grid-cols-2 gap-x-4 gap-y-2.5 bg-[#181a20] border-b border-white/[0.06] px-4 py-3">
          <div className="flex min-w-0 flex-col gap-0.5">
            <span className="text-2xs text-white/40">24h High</span>
            <span className="truncate text-micro font-semibold tabular-nums text-white/90">{formatPrice(feed.high24h) ?? "—"}</span>
          </div>
          <div className="flex min-w-0 flex-col gap-0.5">
            <span className="text-2xs text-white/40">24h Low</span>
            <span className="truncate text-micro font-semibold tabular-nums text-white/90">{formatPrice(feed.low24h) ?? "—"}</span>
          </div>
          <div className="flex min-w-0 flex-col gap-0.5">
            <span className="text-2xs text-white/40">24h Vol({base})</span>
            <span className="truncate text-micro font-semibold tabular-nums text-white/90">{feed.volume24h !== null ? feed.volume24h.toLocaleString("en-US", { maximumFractionDigits: 2 }) : "—"}</span>
          </div>
          <div className="flex min-w-0 flex-col gap-0.5">
            <span className="text-2xs text-white/40">24h Vol({quote})</span>
            <span className="truncate text-micro font-semibold tabular-nums text-white/90">{feed.volume24h !== null && feed.price !== null ? (feed.volume24h * feed.price).toLocaleString("en-US", { maximumFractionDigits: 0 }) : "—"}</span>
          </div>
          <div className="col-span-2 flex flex-col gap-0.5">
            <span className="text-2xs text-white/40">24h Change</span>
            <span className={`text-micro font-semibold tabular-nums ${changeColor}`}>
              {feed.change24h !== null ? formatPrice(feed.change24h) : "—"}
              {feed.changePercent24h !== null ? ` (${feed.changePercent24h >= 0 ? "+" : ""}${feed.changePercent24h.toFixed(2)}%)` : ""}
            </span>
          </div>
        </div>
        {mobileMode === "chart" ? (
          // --- CHART VIEW ---
          <div className="flex flex-col flex-1 overflow-auto custom-scrollbar pb-[65px]">
            <div className="h-[400px] shrink-0 bg-[#181a20]">
              <CandlestickChart
                key={selectedPair}
                symbol={selectedPair}
                market="spot"
                orderBook={orderBook}
                orderLevels={chartOrderLevels}
                priceRange={{ min: feed.low24h, max: feed.high24h }}
                lastPrice={lastTradedPrice}
                onLastPriceChange={setChartLastPrice}
              />
            </div>
            
            {/* Bottom Action Bar */}
            <div className="bg-[#181a20] py-4 px-6 flex justify-center gap-4">
              <button onClick={() => { setQuickOrderSide("buy"); setQuickOrderOpen(true); }} className="flex-1 max-w-[160px] bg-[#2ecc71] text-white font-bold rounded-full py-2.5 text-sm active:scale-95 transition-transform">
                Buy
              </button>
              <button onClick={() => { setQuickOrderSide("sell"); setQuickOrderOpen(true); }} className="flex-1 max-w-[160px] bg-[#e74c3c] text-white font-bold rounded-full py-2.5 text-sm active:scale-95 transition-transform">
                Sell
              </button>
            </div>

            <OrderBookTabs
              className="min-[1150px]:hidden shrink-0"
              fixedHeight={320}
              buyOrders={orderBook.buyOrders}
              sellOrders={orderBook.sellOrders}
              recentTrades={recentTrades}
              recentTradesLoading={recentTradesLoading}
              base={base}
              quote={quote}
              currentPrice={chartLastPrice ?? feed.price}
              buyPercentage={orderBook.buyPercentage}
              sellPercentage={orderBook.sellPercentage}
              isConnected={orderBook.isConnected}
              lastUpdated={orderBook.lastUpdated}
              onSelectPrice={setClickedPrice}
            />
            {/* Legacy mobile book markup kept hidden while the shared panel handles both tabs. */}
            <Tabs className="hidden" defaultValue="orderbook" classNames={{
              tab: "!py-3 !px-4 hover:!bg-transparent data-[active]:!border-b-[2px] data-[active]:!border-primary data-[active]:!text-primary !border-b-[2px] !border-transparent !rounded-none font-bold text-sm text-white/50",
              list: "border-b border-white/[0.06] flex items-center before:!border-0 w-full",
              panel: "!p-0"
            }}>
              <TabsList>
                <TabsTab value="orderbook">Order Book</TabsTab>
                <TabsTab value="trades">Trades</TabsTab>
              </TabsList>
              
              <TabsPanel value="orderbook">
                <div className="flex flex-col p-2">
                  <div className="grid grid-cols-2 gap-2">
                    {/* Bids (Left) */}
                    <div className="flex flex-col gap-1">
                      <div className="flex justify-between text-2xs text-white/40 mb-1 px-1">
                        <span>Qty</span><span>Price</span>
                      </div>
                      {orderBook.buyOrders.map((order, i) => {
                        const w = Math.min((order.quantity / maxBidVol) * 100, 100);
                        return (
                          <div key={`bid-${i}`} onClick={() => setClickedPrice(order.price)} className="flex justify-between relative py-0.5 px-1 cursor-pointer">
                            <div className="absolute top-0 right-0 bottom-0 bg-success-6/[0.08]" style={{ width: `${w}%` }} />
                            <span className="text-micro font-mono text-white/80 z-10">{order.quantity.toFixed(4)}</span>
                            <span className="text-micro font-mono text-success-6 z-10">{order.price.toLocaleString("en-US", { minimumFractionDigits: 2 })}</span>
                          </div>
                        )
                      })}
                    </div>
                    {/* Asks (Right) */}
                    <div className="flex flex-col gap-1">
                      <div className="flex justify-between text-2xs text-white/40 mb-1 px-1">
                        <span>Price</span><span>Qty</span>
                      </div>
                      {[...orderBook.sellOrders].reverse().map((order, i) => {
                        const w = Math.min((order.quantity / maxAskVol) * 100, 100);
                        return (
                          <div key={`ask-${i}`} onClick={() => setClickedPrice(order.price)} className="flex justify-between relative py-0.5 px-1 cursor-pointer">
                            <div className="absolute top-0 left-0 bottom-0 bg-error-1/[0.08]" style={{ width: `${w}%` }} />
                            <span className="text-micro font-mono text-error-1 z-10">{order.price.toLocaleString("en-US", { minimumFractionDigits: 2 })}</span>
                            <span className="text-micro font-mono text-white/80 z-10">{order.quantity.toFixed(4)}</span>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                </div>
              </TabsPanel>
              
              <TabsPanel value="trades">
                <div className="flex flex-col p-2">{renderRecentTrades(30)}</div>
              </TabsPanel>
            </Tabs>

          </div>
        ) : (
          // --- TRADE VIEW ---
          <div className="flex flex-col flex-1 overflow-auto custom-scrollbar pb-[65px]">
            <div className="flex bg-[#181a20] shrink-0">
              {/* Left Side: Trade Form */}
              <div className="w-full">
                <Tabs
                  classNames={{
                    tab: "!py-3 !px-2 flex-1 hover:!bg-transparent data-[active]:!border-b-[2px] data-[active]:!border-primary data-[active]:!text-white !border-b-[2px] !border-transparent !rounded-none font-bold text-xs text-white/40",
                    list: "border-b border-white/[0.06] flex items-center before:!border-0 w-full mb-3",
                    panel: "!px-3 !pb-4",
                  }}
                  value={quickOrderSide}
                  onChange={(v) => setQuickOrderSide(v as "buy"|"sell")}
                >
                  <TabsList>
                    <TabsTab value="buy" className="data-[active]:!text-[#2ecc71] data-[active]:!border-[#2ecc71]">Buy</TabsTab>
                    <TabsTab value="sell" className="data-[active]:!text-[#e74c3c] data-[active]:!border-[#e74c3c]">Sell</TabsTab>
                  </TabsList>
                  <TabsPanel value="buy">
                    <PlaceSpot pair={selectedPair} mode="spot" leverage={1} marketPrice={effectiveMarketPrice} clickedPrice={clickedPrice} compactSide="buy" onTpslChange={setTpslPreview} onFill={setPlacedFill} />
                  </TabsPanel>
                  <TabsPanel value="sell">
                    <PlaceSpot pair={selectedPair} mode="spot" leverage={1} marketPrice={effectiveMarketPrice} clickedPrice={clickedPrice} compactSide="sell" onTpslChange={setTpslPreview} onFill={setPlacedFill} />
                  </TabsPanel>
                </Tabs>
              </div>

              {/* Right Side: Stacked Order Book */}
              <div className="hidden">
                <div className="flex justify-between text-2xs text-white/40 mb-2 px-1">
                  <span>Price</span><span>Qty</span>
                </div>
                {/* Asks */}
                <div className="flex flex-col justify-end flex-1 overflow-hidden gap-[2px]">
                  {[...orderBook.sellOrders].reverse().slice(-10).map((order, i) => {
                    const w = Math.min((order.quantity / maxAskVol) * 100, 100);
                    return (
                      <div key={`ask-${i}`} onClick={() => setClickedPrice(order.price)} className="flex justify-between relative py-0.5 px-1 cursor-pointer">
                        <div className="absolute top-0 right-0 bottom-0 bg-error-1/[0.08]" style={{ width: `${w}%` }} />
                        <span className="text-micro font-mono text-error-1 z-10">{order.price.toLocaleString("en-US", { minimumFractionDigits: 2 })}</span>
                        <span className="text-micro font-mono text-white/80 z-10">{order.quantity.toFixed(4)}</span>
                      </div>
                    )
                  })}
                </div>
                
                {/* Current Price */}
                <div className="py-2 px-1 flex flex-col my-1">
                  <span className={clsx("text-caption font-bold font-mono", changeColor)}>
                    {effectiveMarketPrice !== null ? formatPrice(effectiveMarketPrice) : "—"}
                  </span>
                  <span className="text-2xs text-white/40">
                    ${effectiveMarketPrice !== null ? formatPrice(effectiveMarketPrice) : "—"}
                  </span>
                </div>

                {/* Bids */}
                <div className="flex flex-col flex-1 overflow-hidden gap-[2px]">
                  {orderBook.buyOrders.slice(0, 10).map((order, i) => {
                    const w = Math.min((order.quantity / maxBidVol) * 100, 100);
                    return (
                      <div key={`bid-${i}`} onClick={() => setClickedPrice(order.price)} className="flex justify-between relative py-0.5 px-1 cursor-pointer">
                        <div className="absolute top-0 right-0 bottom-0 bg-success-6/[0.08]" style={{ width: `${w}%` }} />
                        <span className="text-micro font-mono text-success-6 z-10">{order.price.toLocaleString("en-US", { minimumFractionDigits: 2 })}</span>
                        <span className="text-micro font-mono text-white/80 z-10">{order.quantity.toFixed(4)}</span>
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>

            <OrderBookTabs
              className="min-[1150px]:hidden shrink-0"
              fixedHeight={320}
              buyOrders={orderBook.buyOrders}
              sellOrders={orderBook.sellOrders}
              recentTrades={recentTrades}
              recentTradesLoading={recentTradesLoading}
              base={base}
              quote={quote}
              currentPrice={chartLastPrice ?? feed.price}
              buyPercentage={orderBook.buyPercentage}
              sellPercentage={orderBook.sellPercentage}
              isConnected={orderBook.isConnected}
              lastUpdated={orderBook.lastUpdated}
              onSelectPrice={setClickedPrice}
            />

            {/* Mobile trading panel */}
            <TradingPanel selectedPair={selectedPair} market="spot" mobile className="rounded mt-2 min-h-[420px]" />
          </div>
        )}
      </div>

      <MobileBottomSheet opened={quickOrderOpen} onClose={() => setQuickOrderOpen(false)} title="Quick Order">
        <div className="p-4 flex flex-col">
          <Tabs
            classNames={{
              tab: "!py-3 !px-2 flex-1 hover:!bg-transparent data-[active]:!border-b-[2px] data-[active]:!text-white !border-b-[2px] !border-transparent !rounded-none font-bold text-sm text-white/40",
              list: "border-b border-white/[0.06] flex items-center before:!border-0 w-full mb-4",
              panel: "!px-0 !pb-4",
            }}
            value={quickOrderSide}
            onChange={(v) => setQuickOrderSide(v as "buy" | "sell")}
          >
            <TabsList>
              <TabsTab value="buy" className="data-[active]:!text-[#2ecc71] data-[active]:!border-[#2ecc71]">Buy</TabsTab>
              <TabsTab value="sell" className="data-[active]:!text-[#e74c3c] data-[active]:!border-[#e74c3c]">Sell</TabsTab>
            </TabsList>
            <TabsPanel value="buy">
              <PlaceSpot pair={selectedPair} mode="spot" leverage={1} marketPrice={effectiveMarketPrice} clickedPrice={clickedPrice} compactSide="buy" onTpslChange={setTpslPreview} onFill={setPlacedFill} />
            </TabsPanel>
            <TabsPanel value="sell">
              <PlaceSpot pair={selectedPair} mode="spot" leverage={1} marketPrice={effectiveMarketPrice} clickedPrice={clickedPrice} compactSide="sell" onTpslChange={setTpslPreview} onFill={setPlacedFill} />
            </TabsPanel>
          </Tabs>
        </div>
      </MobileBottomSheet>

            <MobileBottomNav />
    </div>
  );
}

export default function SpotTradePage() {
  return (
    <Suspense fallback={<SpotTradePageSkeleton />}>
      <SpotTrades />
    </Suspense>
  );
}
